import { useEffect, useMemo, useState } from "react";
import Icon from "./Icon";
import { Modal } from "./kit";
import MuscleMap, { MuscleLegend, muscleName } from "./MuscleMap";
import { exerciseAnim, exerciseImage } from "../store/db";
import { clock, parseRest } from "../lib/format";

export const GROUPS = ["Pecho", "Espalda", "Hombros", "Bíceps", "Tríceps", "Antebrazos", "Abdomen", "Glúteos", "Cuádriceps", "Isquiotibiales", "Pantorrillas", "Cuerpo completo", "Cardio", "Estiramiento"];
export const LEVELS = ["Principiante", "Intermedio", "Avanzado"];
export const MUSCLE_KEYS = ["chest", "shoulders", "biceps", "triceps", "forearms", "abdominals", "lats", "middle back", "lower back", "traps", "glutes", "quadriceps", "hamstrings", "adductors", "abductors", "calves", "neck"];
const LEVEL_TONE = { Principiante: "ok", Intermedio: "info", Avanzado: "warn" };

/* ---------- filtros ---------- */
export function useExerciseFilters(list, coachId) {
  const [f, setF] = useState({ q: "", group: "Todos", equipment: "", level: "", mine: false, muscle: "" });
  const norm = (s) => (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const base = useMemo(() => list.filter((e) =>
    (!f.q || norm(`${e.name} ${e.muscle} ${e.equipment} ${(e.primary || []).map(muscleName).join(" ")}`).includes(norm(f.q))) &&
    (!f.equipment || e.equipment === f.equipment) &&
    (!f.level || e.level === f.level) &&
    (!f.mine || e.coachId === coachId) &&
    (!f.muscle || (e.primary || []).includes(f.muscle))), [list, f.q, f.equipment, f.level, f.mine, f.muscle, coachId]);
  const shown = useMemo(() => base.filter((e) => f.group === "Todos" || e.muscle === f.group).sort((a, b) => a.name.localeCompare(b.name, "es")), [base, f.group]);
  const groups = useMemo(() => {
    const extra = [...new Set(list.map((e) => e.muscle))].filter((g) => g && !GROUPS.includes(g));
    return ["Todos", ...GROUPS, ...extra].map((g) => ({ g, n: g === "Todos" ? base.length : base.filter((e) => e.muscle === g).length })).filter((x) => x.g === "Todos" || x.n > 0 || x.g === f.group);
  }, [list, base, f.group]);
  const equipment = useMemo(() => [...new Set(list.map((e) => e.equipment).filter(Boolean))].sort((a, b) => a.localeCompare(b, "es")), [list]);
  const muscleCount = useMemo(() => {
    const c = {};
    list.forEach((e) => (e.primary || []).forEach((m) => { c[m] = (c[m] || 0) + 1; }));
    return c;
  }, [list]);
  // La biblioteca tiene más de mil ejercicios: se muestran de 60 en 60
  const [limit, setLimit] = useState(PAGE);
  useEffect(() => setLimit(PAGE), [f]);
  const page = useMemo(() => shown.slice(0, limit), [shown, limit]);
  return { f, setF, shown, page, more: () => setLimit((n) => n + PAGE), groups, equipment, muscleCount, total: list.length };
}
const PAGE = 60;

/** Botón «Mostrar más» bajo la cuadrícula. */
export function MoreExercises({ state }) {
  const left = state.shown.length - state.page.length;
  if (left <= 0) return null;
  return <button className="btn btn-quiet" style={{ alignSelf: "center", marginTop: 12 }} onClick={state.more}>Mostrar más ({left})</button>;
}

export function ExerciseFilters({ state, idPrefix = "ex", showMine, bodyOpen = false }) {
  const { f, setF, groups, equipment, muscleCount } = state;
  const [body, setBody] = useState(bodyOpen);
  const active = f.equipment || f.level || f.mine || f.q || f.muscle;
  return (
    <div className="stack gap-sm">
      <div className="row wrap" style={{ gap: 10 }}>
        <div className="search">
          <Icon name="search" size={18} />
          <label className="sr-only" htmlFor={`${idPrefix}-q`}>Buscar ejercicio</label>
          <input id={`${idPrefix}-q`} className="input" placeholder="Buscar por nombre o músculo" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} />
        </div>
        <label className="sr-only" htmlFor={`${idPrefix}-eq`}>Equipo</label>
        <select id={`${idPrefix}-eq`} className="select" style={{ width: "auto", minWidth: 170 }} value={f.equipment} onChange={(e) => setF({ ...f, equipment: e.target.value })}>
          <option value="">Todo el equipo</option>
          {equipment.map((x) => <option key={x}>{x}</option>)}
        </select>
        <div className="seg" role="group" aria-label="Nivel">
          <button aria-pressed={!f.level} onClick={() => setF({ ...f, level: "" })}>Todos</button>
          {LEVELS.map((l) => <button key={l} aria-pressed={f.level === l} onClick={() => setF({ ...f, level: l })}>{l}</button>)}
        </div>
        {showMine && <label className="toggle small"><input type="checkbox" checked={f.mine} onChange={(e) => setF({ ...f, mine: e.target.checked })} />Solo míos</label>}
        <button type="button" className={`btn btn-sm ${body ? "btn-primary" : "btn-quiet"}`} aria-expanded={body} onClick={() => setBody(!body)}>
          <Icon name="user" size={15} />Por músculo
        </button>
        {active && <button className="link-btn small" onClick={() => setF({ q: "", group: f.group, equipment: "", level: "", mine: false, muscle: "" })}>Limpiar filtros</button>}
      </div>
      {body && (
        <div className="body-picker">
          <MuscleMap selected={f.muscle || null} onSelect={(m) => setF({ ...f, muscle: f.muscle === m ? "" : m, group: "Todos" })}
            describe={(m) => `${muscleCount[m] || 0} ejercicios`} height={250} bodyToggle
            hint={f.muscle ? undefined : "Toca un músculo para ver sus ejercicios"} />
        </div>
      )}
      {f.muscle && (
        <div className="row gap-sm wrap">
          <span className="small muted">Músculo principal:</span>
          <button type="button" className="chip" aria-pressed="true" onClick={() => setF({ ...f, muscle: "" })} aria-label={`Quitar filtro ${muscleName(f.muscle)}`}>
            {muscleName(f.muscle)}<Icon name="x" size={14} />
          </button>
        </div>
      )}
      <div className="chips ex-groups" role="group" aria-label="Grupo muscular">
        {groups.map(({ g, n }) => (
          <button key={g} className="chip" aria-pressed={f.group === g} onClick={() => setF({ ...f, group: g })}>{g}<span className="chip-n">{n}</span></button>
        ))}
      </div>
    </div>
  );
}

/* ---------- tarjeta ---------- */
export function ExerciseTile({ ex, onOpen, action }) {
  const img0 = exerciseImage(ex, 0), img1 = exerciseImage(ex, 1);
  return (
    <div className="ex-tile">
      <button className="ex-tile-media" onClick={() => onOpen(ex)} aria-label={`Ver ${ex.name}`}>
        {img0 ? (
          <>
            <img src={img0} alt="" loading="lazy" />
            {img1 && img1 !== img0 && <img src={img1} alt="" loading="lazy" className="alt" />}
          </>
        ) : <div className="ex-tile-map"><MuscleMap primary={ex.primary || []} secondary={ex.secondary || []} height={112} hint={false} /></div>}
        {ex.coachId && <span className="ex-badge">Tuyo</span>}
      </button>
      <div className="ex-tile-body">
        <button className="ex-tile-name" onClick={() => onOpen(ex)}>{ex.name}</button>
        <div className="tiny muted ellipsis">{ex.muscle} · {ex.equipment}</div>
        <div className="row spread gap-sm" style={{ marginTop: 6 }}>
          {ex.level ? <span className={`pill ${LEVEL_TONE[ex.level] || ""}`}>{ex.level}</span> : <span />}
          {action}
        </div>
      </div>
    </div>
  );
}

/* ---------- ficha ---------- */
export function ExerciseDetail({ ex, onClose, footer, coachName }) {
  const anim = exerciseAnim(ex);
  const frames = anim ? [anim] : [exerciseImage(ex, 0), exerciseImage(ex, 1)].filter(Boolean);
  const unique = [...new Set(frames)];
  const [frame, setFrame] = useState(0);
  const [play, setPlay] = useState(unique.length > 1);
  useEffect(() => {
    if (!play || unique.length < 2) return;
    const t = setInterval(() => setFrame((x) => (x + 1) % unique.length), 1100);
    return () => clearInterval(t);
  }, [play, unique.length]);
  const steps = ex.steps || [];
  return (
    <Modal title={ex.name} onClose={onClose} wide footer={footer}>
      <div className="ex-detail">
        <div className="stack gap-sm">
          {unique.length ? (
            <div className="ex-frames">
              {unique.map((src, i) => <img key={src} src={src} alt={anim ? `Técnica de ${ex.name}` : i === 0 ? "Posición inicial" : "Posición final"} className={i === frame ? "on" : ""} />)}
            </div>
          ) : null}
          {unique.length > 1 && (
            <div className="row spread wrap gap-sm">
              <div className="seg" role="group" aria-label="Posición">
                <button aria-pressed={frame === 0 && !play} onClick={() => { setPlay(false); setFrame(0); }}>Inicio</button>
                <button aria-pressed={frame === 1 && !play} onClick={() => { setPlay(false); setFrame(1); }}>Final</button>
              </div>
              <button className="btn btn-quiet btn-sm" onClick={() => setPlay(!play)}><Icon name={play ? "pause" : "play"} size={14} />{play ? "Pausar" : "Animar"}</button>
            </div>
          )}
          <div className="row wrap gap-xs">
            <span className="pill info">{ex.muscle}</span>
            <span className="tag">{ex.equipment}</span>
            {ex.level && <span className={`pill ${LEVEL_TONE[ex.level] || ""}`}>{ex.level}</span>}
            {ex.type && <span className="tag">{ex.type}</span>}
          </div>
          {(ex.sets || ex.reps) && (
            <p className="small muted">Sugerido: <strong className="ink2 num">{ex.sets} × {ex.reps}</strong> · descanso {clock(parseRest(ex.rest))}</p>
          )}
        </div>
        <div className="stack">
          <div className="ex-map-box">
            <MuscleMap primary={ex.primary || []} secondary={ex.secondary || []} height={250} bodyToggle />
            <MuscleLegend primary={ex.primary || []} secondary={ex.secondary || []} />
          </div>
          {steps.length > 0 && (
            <div className="stack gap-sm">
              <span className="section-title" style={{ fontSize: 17 }}>Cómo se hace</span>
              <ol className="ex-steps">{steps.map((s, i) => <li key={i}>{s}</li>)}</ol>
            </div>
          )}
          {ex.cues && <div className="note-box small"><Icon name="note" size={16} /><span><strong>{coachName ? `${coachName}:` : "Consejo:"}</strong> {ex.cues}</span></div>}
          {anim && <p className="tiny muted">Animación © Gym visual — gymvisual.com</p>}
        </div>
      </div>
    </Modal>
  );
}
