import { useState } from "react";
import Icon from "../../ui/Icon";
import { Empty } from "../../ui/kit";
import { useApp } from "../../context";
import { bestSet, clientById, exerciseById, exerciseImage, lastPerformance, nextDay, useDB, userById } from "../../store/db";
import { ExerciseDetail } from "../../ui/exercises";
import { clock, kg, parseRest } from "../../lib/format";
import { estimateMin } from "./ClientHome";
import { dropLabel, isDrop, setText } from "../../workout/dropset";
import { trialInfo } from "../../lib/trial";
import RoutineEditor from "../coach/RoutineEditor";
import { effortHelp, effortLabel, supersets, tempoHelp } from "../../workout/techniques";

export default function MyRoutine() {
  const db = useDB();
  const { me, openWorkout, go } = useApp();
  const c = clientById(db, me.id);
  const coach = userById(db, c.coachId);
  const [dayId, setDayId] = useState(() => nextDay(db, me.id)?.id);
  const active = db.active[me.id];
  const [view, setView] = useState(null);
  const [editing, setEditing] = useState(false);

  // Modo atleta (se entrena a sí mismo): arma y edita su propia rutina
  if (c.selfCoached && (editing || !c.routine)) {
    return (
      <div className="page" style={{ maxWidth: 980 }}>
        <div className="page-head">
          <div><h1>{c.routine ? "Editar mi rutina" : "Mi rutina"}</h1><p>Tú decides los días, ejercicios, series y descansos.</p></div>
          {c.routine && <button className="btn btn-ghost" onClick={() => setEditing(false)}>Volver</button>}
        </div>
        <RoutineEditor clientId={me.id} self onSaved={() => setEditing(false)} />
      </div>
    );
  }
  if (!c.routine) {
    return <div className="page"><section className="panel"><Empty icon="dumbbell" title="Aún no tienes rutina" text={`${coach.name.split(" ")[0]} la está preparando.`} /></section></div>;
  }
  const day = c.routine.days.find((d) => d.id === dayId) || c.routine.days[0];

  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div className="page-head">
        <div>
          <h1>{c.routine.name}</h1>
          {trialInfo(c)?.running && <span className="pill info" style={{ marginTop: 6 }}><Icon name="clock" size={12} />Rutina de prueba · quedan {trialInfo(c).daysLeft} días</span>}
          <p>{c.routine.goal} · {c.routine.frequency} entrenamientos por semana{c.selfCoached ? "" : ` · preparada por ${coach.name}`}</p>
        </div>
        {c.selfCoached && <button className="btn btn-quiet" onClick={() => setEditing(true)}><Icon name="pencil" size={17} />Editar</button>}
        <button className="btn btn-primary" onClick={() => openWorkout(active ? undefined : day.id)}><Icon name="play" size={18} />{active ? "Continuar entrenamiento" : `Empezar ${day.name}`}</button>
      </div>

      {c.routine.notes && <div className="note-box"><Icon name="note" size={18} /><span>{!c.selfCoached && <strong>{coach.name.split(" ")[0]}: </strong>}{c.routine.notes}</span></div>}

      <div className="tabs" role="tablist">
        {c.routine.days.map((d) => <button key={d.id} role="tab" className="tab" aria-selected={d.id === day.id} onClick={() => setDayId(d.id)}>{d.name}<span className="tiny muted num">{d.exercises.length}</span></button>)}
      </div>
      <p className="small muted">{day.exercises.length} ejercicios · unos {estimateMin(day)} minutos</p>

      <ol className="stack" style={{ listStyle: "none", margin: 0, padding: 0 }}>
        {(() => { const ss = supersets(day.exercises); return day.exercises.map((e, i) => {
          const g = ss[i];
          const info = exerciseById(db, e.exId);
          const last = lastPerformance(db, me.id, e.exId);
          const best = bestSet(db, me.id, e.exId);
          return (
            <li key={e.uid} className={`panel panel-pad stack ${g ? "in-ss" : ""} ${g && g.pos < g.size ? "ss-joined" : ""}`} style={{ gap: 10 }}>
              {g && g.pos === 1 && <div className="ss-head" style={{ margin: "-4px 0 0" }}><Icon name="link" size={15} /><strong>Superserie {g.letter}</strong><span>{g.size} ejercicios seguidos, sin descanso entre ellos</span></div>}
              <div className="row" style={{ alignItems: "flex-start" }}>
                {exerciseImage(info) ? (
                  <button className="ex-thumb-btn" onClick={() => setView(info)} aria-label={`Ver técnica de ${info.name}`}>
                    <img className="ex-thumb" src={exerciseImage(info)} alt="" style={{ width: 84, height: 60 }} />
                  </button>
                ) : <span className="display num" style={{ fontSize: 30, width: 28, lineHeight: 1, color: "var(--muted)" }}>{i + 1}</span>}
                <div className="grow" style={{ minWidth: 0 }}>
                  <div className="section-title" style={{ overflowWrap: "anywhere" }}>{g && <span className="ss-tag">{g.letter}{g.pos}</span>}{info.name}</div>
                  <div className="small muted">{info.muscle} · {info.equipment}</div>
                  <div className="narrow-only small strong num" style={{ marginTop: 2 }}>{e.sets} × {e.reps} <span className="muted" style={{ fontWeight: 400 }}>· descanso {clock(parseRest(e.rest))}</span></div>
                  <button className="link-btn small" style={{ fontSize: 13 }} onClick={() => setView(info)}>Ver técnica</button>
                </div>
                <div className="wide-only" style={{ textAlign: "right", flexShrink: 0 }}>
                  <div className="display num" style={{ fontSize: 24, lineHeight: 1, whiteSpace: "nowrap" }}>{e.sets} × {e.reps}</div>
                  <div className="tiny muted num">descanso {clock(parseRest(e.rest))}</div>
                </div>
              </div>
              {(isDrop(e) || e.effort || e.tempo) && (
                <div className="row wrap gap-xs">
                  {isDrop(e) && <span className="drop-badge"><Icon name="trend" size={13} />{dropLabel(e.drops)}</span>}
                  {e.effort && <span className="tech-badge" title={effortHelp(e.effort)}><Icon name="gauge" size={13} />{effortLabel(e.effort)}</span>}
                  {e.tempo && <span className="tech-badge" title={tempoHelp(e.tempo)}><Icon name="clock" size={13} />Tempo {e.tempo}</span>}
                </div>)}
              {(e.effort || e.tempo) && <p className="tiny muted" style={{ margin: 0 }}>{[effortHelp(e.effort), tempoHelp(e.tempo)].filter(Boolean).join(" · ")}</p>}
              {info.cues && <p className="small ink2">{info.cues}</p>}
              {e.notes && <div className="note-box small"><Icon name="note" size={16} /><span>{!c.selfCoached && <strong>{coach.name.split(" ")[0]}: </strong>}{e.notes}</span></div>}
              {(last || best) && (
                <div className="row wrap small muted gap-sm">
                  {last && <span>Última vez: <span className="num ink2">{last.sets.map((s) => setText(s)).join(" · ")}</span></span>}
                  {best && best.weight > 0 && <span className="tag" style={{ background: "var(--yellow-soft)", color: "var(--yellow-ink)" }}><Icon name="trophy" size={13} />{kg(best.weight)} kg</span>}
                </div>
              )}
              {!c.selfCoached && <button className="link-btn small" style={{ alignSelf: "flex-start", fontSize: 13 }} onClick={() => go("mensajes", { exId: e.exId, tag: "comentario" })}>
                <Icon name="chat" size={14} /> Comentar a {coach.name.split(" ")[0]} sobre este ejercicio</button>}
            </li>
          );
        }); })()}
      </ol>
      {view && <ExerciseDetail ex={view} coachName={coach.name.split(" ")[0]} onClose={() => setView(null)} />}
    </div>
  );
}
