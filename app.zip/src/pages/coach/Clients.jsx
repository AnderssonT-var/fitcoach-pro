import { useEffect, useState } from "react";
import Icon from "../../ui/Icon";
import { Avatar, CopyButton, Dots, Empty, Field, Modal, Pill, toast } from "../../ui/kit";
import { useApp } from "../../context";
import { addClient, clientsOf, paymentStatus, useDB, weekCount, workoutsOf } from "../../store/db";
import { ago, daysSince, money } from "../../lib/format";
import { TrialFields, TrialPill } from "./Trial";
import { trialInfo, trialName } from "../../lib/trial";
import { compliance, complianceTone, pendingReviews } from "../../lib/coaching";

export const GOALS = ["Hipertrofia", "Fuerza", "Pérdida de grasa", "Tonificación", "Recomposición", "Rendimiento", "Salud general"];

export default function Clients() {
  const db = useDB();
  const { me, go, params } = useApp();
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("all");
  const [create, setCreate] = useState(!!params.create);
  useEffect(() => { if (params.create) setCreate(true); }, [params]);

  const rows = clientsOf(db, me.id).map((c) => {
    const last = workoutsOf(db, c.userId)[0];
    const pays = db.payments.filter((p) => p.clientId === c.userId);
    const pay = pays.some((p) => paymentStatus(p) === "overdue") ? "overdue" : pays.some((p) => paymentStatus(p) === "pending") ? "pending" : "paid";
    const idle = c.routine && (!last || daysSince(last.finishedAt) >= 7);
    const p7 = compliance(c, db.workouts, 7), p30 = compliance(c, db.workouts, 30);
    const risk = c.active && p7 != null && p30 != null && (p7 < 50 || p30 - p7 >= 20);
    return { ...c, last, pay, idle, week: weekCount(db, c.userId), p7, risk, reviews: pendingReviews(c).length };
  });
  const F = {
    all: (r) => true, active: (r) => r.active, risk: (r) => r.risk, checkin: (r) => r.reviews > 0, trial: (r) => r.active && !!trialInfo(r), noroutine: (r) => r.active && !r.routine,
    overdue: (r) => r.pay === "overdue", idle: (r) => r.active && r.idle, paused: (r) => !r.active,
  };
  const LABELS = [["all", "Todos"], ["risk", "En riesgo"], ["checkin", "Check-in por revisar"], ["active", "Activos"], ["trial", "En prueba"], ["noroutine", "Sin rutina"], ["overdue", "Pago vencido"], ["idle", "Inactivos"], ["paused", "En pausa"]];
  const shown = rows.filter(F[filter]).filter((r) => !q || `${r.user.name} ${r.user.email} ${r.goal} ${(r.tags || []).join(" ")}`.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => a.user.name.localeCompare(b.user.name));

  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Clientes</h1><p>Cada cliente tiene su propia rutina, historial y control de pagos.</p></div>
        <button className="btn btn-primary" onClick={() => setCreate(true)}><Icon name="plus" size={18} />Nuevo cliente</button>
      </div>

      <div className="row wrap" style={{ gap: 10 }}>
        <div className="search">
          <Icon name="search" size={18} />
          <label className="sr-only" htmlFor="cl-q">Buscar cliente</label>
          <input id="cl-q" className="input" placeholder="Buscar por nombre, correo u objetivo" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="chips" role="group" aria-label="Filtrar clientes">
          {LABELS.map(([k, l]) => <button key={k} className="chip" aria-pressed={filter === k} onClick={() => setFilter(k)}>{l}<span className="chip-n">{rows.filter(F[k]).length}</span></button>)}
        </div>
      </div>

      <section className="panel">
        {shown.length === 0 ? (
          <Empty icon="users" title={rows.length ? "Nadie coincide con el filtro" : "Agrega tu primer cliente"}
            text={rows.length ? "Prueba con otro filtro o búsqueda." : "Le crearemos un acceso para que vea su rutina y registre sus entrenamientos."}
            action={!rows.length && <button className="btn btn-primary" onClick={() => setCreate(true)}>Nuevo cliente</button>} />
        ) : (
          <div className="list">
            {shown.map((r) => (
              <button key={r.userId} className="list-row" onClick={() => go("clientes", { id: r.userId })} style={r.active ? null : { opacity: .6 }}>
                <Avatar name={r.user.name} id={r.userId} />
                <div className="grow">
                  <div className="strong ellipsis">{r.user.name}</div>
                  <div className="small muted ellipsis">{r.goal} · {r.routine ? r.routine.name : "sin rutina"} · {r.last ? `entrenó ${ago(r.last.finishedAt)}` : "sin registros"}</div>
                  {(r.risk || r.reviews > 0 || r.tags?.length > 0) && (
                    <div className="row wrap gap-xs" style={{ marginTop: 5 }}>
                      {r.risk && <span className="tag tag-bad">En riesgo</span>}
                      {r.reviews > 0 && <span className="tag tag-warn">Check-in por revisar</span>}
                      {(r.tags || []).map((t) => <span key={t} className="tag">{t}</span>)}
                    </div>)}
                </div>
                {r.p7 != null && <span className="cl-comp"><strong className={`num ${complianceTone(r.p7)}-ink`}>{r.p7}%</strong><span>7 días</span></span>}
                <span className="m-hide row gap-sm" style={{ width: 150 }}>
                  {r.routine ? <><Dots done={r.week} goal={r.routine.frequency} /><span className="small muted num">{r.week}/{r.routine.frequency}</span></> : <Pill tone="warn">Sin rutina</Pill>}
                </span>
                <span className="stack cl-status">
                  {r.active && <TrialPill c={r} short />}
                  {!r.active ? <Pill>En pausa</Pill> : r.pay === "overdue" ? <Pill tone="bad">Vencido</Pill> : r.pay === "pending" ? <Pill tone="warn">Pendiente</Pill> : <Pill tone="ok">Al día</Pill>}
                </span>
                <Icon name="right" size={18} />
              </button>
            ))}
          </div>
        )}
      </section>

      {create && <NewClientModal onClose={() => setCreate(false)} />}
    </div>
  );
}

function NewClientModal({ onClose }) {
  const { me, go } = useApp();
  const [f, setF] = useState({ name: "", email: "", phone: "", goal: "Hipertrofia", weight: "", height: "", fee: "50" });
  const [trial, setTrial] = useState(null); // { days, fee } si empieza con plan de prueba
  const [error, setError] = useState("");
  const [created, setCreated] = useState(null);
  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setError(""); };

  const [busy, setBusy] = useState(false);
  async function save() {
    if (!f.name.trim()) return setError("Escribe el nombre del cliente.");
    if (!/^\S+@\S+\.\S+$/.test(f.email)) return setError("Escribe un correo válido: lo usará para entrar.");
    setBusy(true);
    const r = await addClient(me.id, { ...f, trial });
    setBusy(false);
    if (r.error) return setError(r.error);
    setCreated(r);
    toast(`${f.name.split(" ")[0]} agregado`, "users");
  }

  if (created) {
    return (
      <Modal title="Cliente agregado" onClose={onClose} footer={<>
        <button className="btn btn-quiet" onClick={onClose}>Cerrar</button>
        <button className="btn btn-primary" onClick={() => { onClose(); go("clientes", { id: created.user.id, tab: "rutina" }); }}>{trial ? "Crear su rutina de prueba" : "Crear su rutina"}</button>
      </>}>
        <p className="ink2">Comparte estos datos con {created.user.name.split(" ")[0]} por un medio privado (la contraseña solo se muestra ahora). Al entrar deberá aceptar el aviso de privacidad y crear su propia contraseña.</p>
        <div className="panel list">
          <div className="list-row"><span className="grow"><span className="tiny muted">Correo</span><br /><strong>{created.user.email}</strong></span><CopyButton text={created.user.email} small /></div>
          <div className="list-row"><span className="grow"><span className="tiny muted">Contraseña temporal</span><br /><strong className="num">{created.password}</strong></span><CopyButton text={created.password} small /></div>
        </div>
        {trial ? <div className="note-box"><Icon name="clock" size={18} /><span>Empieza con {trialName(+trial.days).toLowerCase()}{+trial.fee > 0 ? ` (cobro de ${money(+trial.fee)} registrado)` : " gratis"}. Crea su rutina de prueba y deja listo el plan completo: se activa solo al terminar{+f.fee > 0 ? `, con mensualidad de ${money(+f.fee)}` : ""}.</span></div>
          : +f.fee > 0 && <div className="note-box"><Icon name="wallet" size={18} />Se registró la primera mensualidad de {money(+f.fee)} como pendiente.</div>}
      </Modal>
    );
  }

  return (
    <Modal title="Nuevo cliente" onClose={onClose} footer={<>
      <button className="btn btn-quiet" onClick={onClose}>Cancelar</button>
      <button className="btn btn-primary" onClick={save} disabled={busy}>{busy ? "Agregando…" : "Agregar cliente"}</button>
    </>}>
      <div className="form-grid">
        <div className="full"><Field label="Nombre completo" id="nc-name"><input id="nc-name" className="input" value={f.name} onChange={set("name")} autoComplete="off" /></Field></div>
        <Field label="Correo" id="nc-email"><input id="nc-email" className="input" type="email" value={f.email} onChange={set("email")} autoComplete="off" /></Field>
        <Field label="Teléfono" id="nc-phone"><input id="nc-phone" className="input" type="tel" value={f.phone} onChange={set("phone")} /></Field>
        <Field label="Objetivo" id="nc-goal"><select id="nc-goal" className="select" value={f.goal} onChange={set("goal")}>{GOALS.map((g) => <option key={g}>{g}</option>)}</select></Field>
        <Field label={trial ? "Mensualidad del plan completo" : "Mensualidad"} id="nc-fee"><input id="nc-fee" className="input num" type="number" inputMode="decimal" value={f.fee} onChange={set("fee")} /></Field>
        <Field label="Peso actual (kg)" id="nc-w"><input id="nc-w" className="input num" type="number" inputMode="decimal" value={f.weight} onChange={set("weight")} /></Field>
        <Field label="Estatura (cm)" id="nc-h"><input id="nc-h" className="input num" type="number" inputMode="numeric" value={f.height} onChange={set("height")} /></Field>
      </div>
      <div className={`trial-box ${trial ? "on" : ""}`}>
        <label className="toggle"><input type="checkbox" checked={!!trial} onChange={(e) => setTrial(e.target.checked ? { days: 30, fee: "0" } : null)} />
          <span><strong>Empezar con plan de prueba</strong><br /><span className="small muted">Rutina y precio de prueba; al terminar pasa al plan completo.</span></span></label>
        {trial && <div className="form-grid" style={{ marginTop: 12 }}><TrialFields value={trial} onChange={setTrial} idp="nc-tr" /></div>}
      </div>
      {error && <div className="error-box" role="alert"><Icon name="alert" size={18} />{error}</div>}
    </Modal>
  );
}
